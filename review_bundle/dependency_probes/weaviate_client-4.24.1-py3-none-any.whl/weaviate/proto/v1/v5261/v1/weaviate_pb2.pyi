from weaviate.proto.v1.v5261.v1 import aggregate_pb2 as _aggregate_pb2
from weaviate.proto.v1.v5261.v1 import batch_pb2 as _batch_pb2
from weaviate.proto.v1.v5261.v1 import batch_delete_pb2 as _batch_delete_pb2
from weaviate.proto.v1.v5261.v1 import search_get_pb2 as _search_get_pb2
from weaviate.proto.v1.v5261.v1 import tenants_pb2 as _tenants_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
