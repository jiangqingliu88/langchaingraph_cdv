from typing import Any, Generic, List, Literal, Optional, Type, Union, cast, overload

from weaviate.collections.classes.filters import (
    FilterReturn,
)
from weaviate.collections.classes.generative import (
    GenerativeConfigRuntime,
    GroupedTask,
    SinglePrompt,
)
from weaviate.collections.classes.grpc import (
    METADATA,
    MMR,
    PROPERTIES,
    REFERENCES,
    BoostReturn,
    GroupBy,
    NearVectorInputType,
    Rerank,
    TargetVectorJoinType,
)
from weaviate.collections.classes.internal import (
    CrossReferences,
    GenerativeGroupByReturn,
    GenerativeReturn,
    GenerativeSearchReturnType,
    ReturnProperties,
    ReturnReferences,
    _Generative,
    _GroupBy,
    _QueryOptions,
)
from weaviate.collections.classes.types import (
    Properties,
    References,
    TProperties,
    TReferences,
)
from weaviate.collections.queries.base_executor import _BaseExecutor
from weaviate.connect import executor
from weaviate.connect.v4 import ConnectionType
from weaviate.proto.v1 import search_get_pb2
from weaviate.types import INCLUDE_VECTOR, NUMBER


class _NearVectorGenerateExecutor(
    Generic[ConnectionType, Properties, References], _BaseExecutor[ConnectionType]
):
    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: Literal[None] = None,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Union[PROPERTIES, bool, None] = None,
        return_references: Literal[None] = None,
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeReturn[Properties, References]]: ...

    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: Literal[None] = None,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Union[PROPERTIES, bool, None] = None,
        return_references: REFERENCES,
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeReturn[Properties, CrossReferences]]: ...

    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: Literal[None] = None,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Union[PROPERTIES, bool, None] = None,
        return_references: Type[TReferences],
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeReturn[Properties, TReferences]]: ...

    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: Literal[None] = None,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Type[TProperties],
        return_references: Literal[None] = None,
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeReturn[TProperties, References]]: ...

    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: Literal[None] = None,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Type[TProperties],
        return_references: REFERENCES,
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeReturn[TProperties, CrossReferences]]: ...

    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: Literal[None] = None,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Type[TProperties],
        return_references: Type[TReferences],
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeReturn[TProperties, TReferences]]: ...

    ### GroupBy ###
    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: GroupBy,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Union[PROPERTIES, bool, None] = None,
        return_references: Literal[None] = None,
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeGroupByReturn[Properties, References]]: ...

    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: GroupBy,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Union[PROPERTIES, bool, None] = None,
        return_references: REFERENCES,
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeGroupByReturn[Properties, CrossReferences]]: ...

    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: GroupBy,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Union[PROPERTIES, bool, None] = None,
        return_references: Type[TReferences],
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeGroupByReturn[Properties, TReferences]]: ...

    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: GroupBy,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Type[TProperties],
        return_references: Literal[None] = None,
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeGroupByReturn[TProperties, References]]: ...

    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: GroupBy,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Type[TProperties],
        return_references: REFERENCES,
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeGroupByReturn[TProperties, CrossReferences]]: ...

    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: GroupBy,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Type[TProperties],
        return_references: Type[TReferences],
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[GenerativeGroupByReturn[TProperties, TReferences]]: ...

    ### DEFAULT ###
    @overload
    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: Optional[GroupBy] = None,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Optional[ReturnProperties[TProperties]] = None,
        return_references: Optional[ReturnReferences[TReferences]] = None,
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[
        GenerativeSearchReturnType[Properties, References, TProperties, TReferences]
    ]: ...

    def near_vector(
        self,
        near_vector: NearVectorInputType,
        *,
        single_prompt: Union[str, SinglePrompt, None] = None,
        grouped_task: Union[str, GroupedTask, None] = None,
        grouped_properties: Optional[List[str]] = None,
        generative_provider: Optional[GenerativeConfigRuntime] = None,
        certainty: Optional[NUMBER] = None,
        distance: Optional[NUMBER] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        auto_limit: Optional[int] = None,
        filters: Optional[FilterReturn] = None,
        group_by: Optional[GroupBy] = None,
        rerank: Optional[Rerank] = None,
        boost: Optional[BoostReturn] = None,
        target_vector: Optional[TargetVectorJoinType] = None,
        include_vector: INCLUDE_VECTOR = False,
        return_metadata: Optional[METADATA] = None,
        return_properties: Optional[ReturnProperties[TProperties]] = None,
        return_references: Optional[ReturnReferences[TReferences]] = None,
        diversity_selection: Optional[MMR] = None,
    ) -> executor.Result[
        GenerativeSearchReturnType[Properties, References, TProperties, TReferences]
    ]:
        """Perform retrieval-augmented generation (RaG) on the results of a by-vector object search in this collection using vector-based similarity search.

        See the [docs](https://weaviate.io/developers/weaviate/search/similarity) for a more detailed explanation.

        Args:
            near_vector: The vector to search on, REQUIRED. This can be a base64 encoded string of the binary, a path to the file, or a file-like object.
            certainty: The minimum similarity score to return. If not specified, the default certainty specified by the server is used.
            distance: The maximum distance to search. If not specified, the default distance specified by the server is used.
            limit: The maximum number of results to return. If not specified, the default limit specified by the server is returned.
            offset: The offset to start from. If not specified, the retrieval begins from the first object in the server.
            auto_limit: The maximum number of [autocut](https://weaviate.io/developers/weaviate/api/graphql/additional-operators#autocut) results to return. If not specified, no limit is applied.
            filters: The filters to apply to the search.
            group_by: How the results should be grouped by a specific property.
            rerank: How the results should be reranked. NOTE: A `rerank-*` module must be enabled for this functionality to work.
            boost: A `Boost` that re-scores the search candidates to promote or demote objects without removing them.
            target_vector: The name of the vector space to search in for named vector configurations. Required if multiple spaces are configured.
            include_vector: Whether to include the vector in the results. If not specified, this is set to False.
            return_metadata: The metadata to return for each object, defaults to `None`.
            return_properties: The properties to return for each object.
            return_references: The references to return for each object.
            diversity_selection: Apply diversity selection (e.g. MMR) to the results. Requires Weaviate >= 1.37.0.

        NOTE:
            - If `return_properties` is not provided then all properties are returned except for blob properties.
            - If `return_metadata` is not provided then no metadata is provided. Use MetadataQuery.full() to retrieve all metadata.
            - If `return_references` is not provided then no references are provided.

        Returns:
            A `GenerativeReturn` or `GenerativeGroupByReturn` object that includes the searched objects.
            If `group_by` is provided then a `GenerativeGroupByReturn` object is returned, otherwise a `GenerativeReturn` object is returned.

        Raises:
            weaviate.exceptions.WeaviateGRPCQueryError: If the request to the Weaviate server fails.
        """

        def resp(
            res: search_get_pb2.SearchReply,
        ) -> GenerativeSearchReturnType[Properties, References, TProperties, TReferences]:
            return cast(
                Any,
                self._result_to_generative_return(
                    res,
                    _QueryOptions.from_input(
                        return_metadata,
                        return_properties,
                        include_vector,
                        self._references,
                        return_references,
                        rerank,
                        group_by,
                    ),
                ),
            )

        request = self._query.near_vector(
            near_vector=near_vector,
            certainty=certainty,
            distance=distance,
            filters=filters,
            group_by=_GroupBy.from_input(group_by),
            generative=_Generative(
                single=single_prompt,
                grouped=grouped_task,
                grouped_properties=grouped_properties,
                generative_provider=generative_provider,
            ),
            limit=limit,
            offset=offset,
            autocut=auto_limit,
            rerank=rerank,
            diversity_selection=diversity_selection,
            boost=boost,
            target_vector=target_vector,
            return_metadata=self._parse_return_metadata(return_metadata, include_vector),
            return_properties=self._parse_return_properties(return_properties),
            return_references=self._parse_return_references(return_references),
        )
        return executor.execute(
            response_callback=resp,
            method=self._connection.grpc_search,
            request=request,
        )
