import uuid as uuid_package
from typing import Generic, Iterable, List, Literal, Optional, Sequence, Union, overload

from weaviate.collections.batch.grpc_batch import _BatchGRPC
from weaviate.collections.batch.grpc_batch_delete import _BatchDeleteGRPC
from weaviate.collections.batch.rest import _BatchREST
from weaviate.collections.classes.batch import (
    BatchObjectReturn,
    BatchReferenceReturn,
    DeleteManyObject,
    DeleteManyReturn,
)
from weaviate.collections.classes.data import DataObject, DataReferences
from weaviate.collections.classes.filters import FilterReturn
from weaviate.collections.classes.internal import (
    ReferenceInput,
    ReferenceInputs,
    SingleReferenceInput,
)
from weaviate.collections.classes.types import Properties
from weaviate.connect.v4 import ConnectionSync
from weaviate.types import UUID, VECTORS

from .executor import _DataCollectionExecutor

class _DataCollection(Generic[Properties,], _DataCollectionExecutor[ConnectionSync, Properties]):
    __batch_delete: _BatchDeleteGRPC
    __batch_grpc: _BatchGRPC
    __batch_rest: _BatchREST

    def insert(
        self,
        properties: Properties,
        references: Optional[ReferenceInputs] = None,
        uuid: Optional[UUID] = None,
        vector: Optional[VECTORS] = None,
    ) -> uuid_package.UUID: ...
    def insert_many(
        self,
        objects: Sequence[Union[Properties, DataObject[Properties, Optional[ReferenceInputs]]]],
    ) -> BatchObjectReturn: ...
    def exists(self, uuid: UUID) -> bool: ...
    def replace(
        self,
        uuid: UUID,
        properties: Properties,
        references: Optional[ReferenceInputs] = None,
        vector: Optional[VECTORS] = None,
    ) -> None: ...
    def update(
        self,
        uuid: UUID,
        properties: Optional[Properties] = None,
        references: Optional[ReferenceInputs] = None,
        vector: Optional[VECTORS] = None,
    ) -> None: ...
    def reference_add(
        self, from_uuid: UUID, from_property: str, to: SingleReferenceInput
    ) -> None: ...
    def reference_add_many(self, refs: List[DataReferences]) -> BatchReferenceReturn: ...
    def reference_delete(
        self, from_uuid: UUID, from_property: str, to: SingleReferenceInput
    ) -> None: ...
    def reference_replace(
        self, from_uuid: UUID, from_property: str, to: ReferenceInput
    ) -> None: ...
    def delete_by_id(self, uuid: UUID) -> bool: ...
    @overload
    def delete_many(
        self, where: FilterReturn, *, verbose: Literal[False] = False, dry_run: bool = False
    ) -> DeleteManyReturn[None]: ...
    @overload
    def delete_many(
        self, where: FilterReturn, *, verbose: Literal[True], dry_run: bool = False
    ) -> DeleteManyReturn[List[DeleteManyObject]]: ...
    @overload
    def delete_many(
        self, where: FilterReturn, *, verbose: bool = False, dry_run: bool = False
    ) -> Union[DeleteManyReturn[List[DeleteManyObject]], DeleteManyReturn[None]]: ...
    def ingest(
        self, objs: Iterable[Union[Properties, DataObject[Properties, Optional[ReferenceInputs]]]]
    ) -> BatchObjectReturn: ...
