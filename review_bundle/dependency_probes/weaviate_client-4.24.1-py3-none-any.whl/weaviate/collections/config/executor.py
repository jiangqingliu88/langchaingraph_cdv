import asyncio
from typing import (
    Any,
    Dict,
    Generic,
    List,
    Literal,
    Optional,
    Sequence,
    Tuple,
    Union,
    cast,
    overload,
)

from httpx import Response
from pydantic_core import ValidationError
from typing_extensions import deprecated

from weaviate.collections.classes.config import (
    CollectionConfig,
    CollectionConfigSimple,
    GenerativeProvider,
    IndexName,
    InvertedIndexConfigUpdate,
    MultiTenancyConfigUpdate,
    Property,
    PropertyType,
    ReferenceProperty,
    ReferencePropertyMultiTarget,
    ReplicationConfigUpdate,
    RerankerProvider,
    ShardStatus,
    ShardTypes,
    _CollectionConfigUpdate,
    _ShardStatus,
)
from weaviate.collections.classes.config_methods import (
    _collection_config_from_json,
    _collection_config_simple_from_json,
)
from weaviate.collections.classes.config_named_vectors import (
    _NamedVectorConfigCreate,
    _NamedVectorConfigUpdate,
)
from weaviate.collections.classes.config_object_ttl import ObjectTTLConfigUpdate
from weaviate.collections.classes.config_vector_index import (
    VectorIndexConfigDynamicUpdate,
    VectorIndexConfigFlatUpdate,
    VectorIndexConfigHFreshUpdate,
    VectorIndexConfigHNSWUpdate,
)
from weaviate.collections.classes.config_vectors import (
    VectorConfigCreate,
    VectorConfigUpdate,
)
from weaviate.connect import executor
from weaviate.connect.v4 import ConnectionAsync, ConnectionType, _ExpectedStatusCodes
from weaviate.exceptions import (
    WeaviateInvalidInputError,
    WeaviateUnsupportedFeatureError,
)
from weaviate.util import (
    _capitalize_first_letter,
    _decode_json_response_dict,
    _decode_json_response_list,
)
from weaviate.validator import _validate_input, _ValidateArgument
from weaviate.warnings import _Warnings


def _any_property_has_text_analyzer(properties: Sequence[Property]) -> bool:
    return any(_property_has_text_analyzer(p) for p in properties)


def _property_has_text_analyzer(prop: Property) -> bool:
    if prop.textAnalyzer is not None:
        return True
    nested = prop.nestedProperties
    if nested is None:
        return False
    nested_list = nested if isinstance(nested, list) else [nested]
    return any(_property_has_text_analyzer(np) for np in nested_list)


class _ConfigCollectionExecutor(Generic[ConnectionType]):
    def __init__(
        self,
        connection: ConnectionType,
        name: str,
        tenant: Optional[str] = None,
    ) -> None:
        self._connection = connection
        self._name = name
        self._tenant = tenant

    def __get(self) -> executor.Result[Dict[str, Any]]:
        def resp(res: Response) -> Dict[str, Any]:
            return cast(Dict[str, Any], res.json())

        return executor.execute(
            response_callback=resp,
            method=self._connection.get,
            path=f"/schema/{self._name}",
            error_msg="Collection configuration could not be retrieved.",
            status_codes=_ExpectedStatusCodes(ok_in=200, error="Get collection configuration"),
        )

    @overload
    def get(
        self,
        simple: Literal[False] = False,
    ) -> executor.Result[CollectionConfig]: ...

    @overload
    def get(
        self,
        simple: Literal[True],
    ) -> executor.Result[CollectionConfigSimple]: ...

    @overload
    def get(
        self,
        simple: bool = False,
    ) -> executor.Result[Union[CollectionConfig, CollectionConfigSimple]]: ...

    def get(
        self,
        simple: bool = False,
    ) -> executor.Result[Union[CollectionConfig, CollectionConfigSimple]]:
        """Get the configuration for this collection from Weaviate.

        Args:
            simple: If True, return a simplified version of the configuration containing only name and properties.

        Raises:
            weaviate.exceptions.WeaviateConnectionError: If the network connection to Weaviate fails.
            weaviate.exceptions.UnexpectedStatusCodeError: If Weaviate reports a non-OK status.
        """
        _validate_input([_ValidateArgument(expected=[bool], name="simple", value=simple)])

        def resp(res: Dict[str, Any]) -> Union[CollectionConfig, CollectionConfigSimple]:
            if simple:
                return _collection_config_simple_from_json(res)
            return _collection_config_from_json(res)

        return executor.execute(
            response_callback=resp,
            method=self.__get,
        )

    def update(
        self,
        *,
        description: Optional[str] = None,
        property_descriptions: Optional[Dict[str, str]] = None,
        inverted_index_config: Optional[InvertedIndexConfigUpdate] = None,
        multi_tenancy_config: Optional[MultiTenancyConfigUpdate] = None,
        object_ttl_config: Optional[ObjectTTLConfigUpdate] = None,
        replication_config: Optional[ReplicationConfigUpdate] = None,
        vector_index_config: Optional[
            Union[
                VectorIndexConfigHNSWUpdate,
                VectorIndexConfigFlatUpdate,
                VectorIndexConfigHFreshUpdate,
            ]
        ] = None,
        vectorizer_config: Optional[
            Union[
                VectorIndexConfigHNSWUpdate,
                VectorIndexConfigFlatUpdate,
                VectorIndexConfigDynamicUpdate,
                VectorIndexConfigHFreshUpdate,
                List[_NamedVectorConfigUpdate],
            ]
        ] = None,
        vector_config: Optional[Union[VectorConfigUpdate, List[VectorConfigUpdate]]] = None,
        generative_config: Optional[GenerativeProvider] = None,
        reranker_config: Optional[RerankerProvider] = None,
    ) -> executor.Result[None]:
        """Update the configuration for this collection in Weaviate.

        Use the `weaviate.classes.Reconfigure` class to generate the necessary configuration objects for this method.

        Args:
            description: A description of the collection.
            inverted_index_config: Configuration for the inverted index. Use `Reconfigure.inverted_index` to generate one.
            multi_tenancy_config: Configuration for multi-tenancy settings. Use `Reconfigure.multi_tenancy` to generate one.
                Only `auto_tenant_creation` is supported.
            object_ttl_config: Configuration for object TTL settings. Use `Reconfigure.object_ttl` to generate one.
            replication_config: Configuration for the replication. Use `Reconfigure.replication` to generate one.
            reranker_config: Configuration for the reranker. Use `Reconfigure.replication` to generate one.
            vector_index_config (DEPRECATED use `vector_config`): Configuration for the vector index of the default single vector. Use `Reconfigure.vector_index` to generate one.
            vectorizer_config: Configurations for the vector index (or indices) of your collection.
                Use `Reconfigure.vector_index` if using legacy vectorization and `Reconfigure.NamedVectors` if you have many named vectors to generate them.
                Using this argument with a list of `Reconfigure.NamedVectors` is **DEPRECATED**. Use the `vector_config` argument instead in such a case.
            vector_config: Configuration for the vector index (or indices) of your collection.
                Use `Reconfigure.Vectors` for both single and multiple vectorizers. Supply a list to update many vectorizers at once.

        Raises:
            weaviate.exceptions.WeaviateInvalidInputError: If the input parameters are invalid.
            weaviate.exceptions.WeaviateConnectionError: If the network connection to Weaviate fails.
            weaviate.exceptions.UnexpectedStatusCodeError: If Weaviate reports a non-OK status.

        NOTE:
            - If you wish to update a specific option within the configuration and cannot find it in `CollectionConfigUpdate` then it is an immutable option.
            - To change it, you will have to delete the collection and recreate it with the desired options.
            - This is not the case of adding properties, which can be done with `collection.config.add_property()`.
        """
        if vector_index_config is not None:
            _Warnings.vector_index_config_in_config_update()
        if vectorizer_config is not None and not isinstance(
            vectorizer_config,
            (
                VectorIndexConfigHNSWUpdate,
                VectorIndexConfigFlatUpdate,
                VectorIndexConfigDynamicUpdate,
                VectorIndexConfigHFreshUpdate,
            ),
        ):
            _Warnings.vectorizer_config_in_config_update()
        if (
            inverted_index_config is not None
            and inverted_index_config.stopwordPresets is not None
            and not self._connection._weaviate_version.is_at_least(1, 37, 0)
        ):
            raise WeaviateUnsupportedFeatureError(
                "InvertedIndexConfig stopword_presets",
                str(self._connection._weaviate_version),
                "1.37.0",
            )
        try:
            config = _CollectionConfigUpdate(
                description=description,
                property_descriptions=property_descriptions,
                inverted_index_config=inverted_index_config,
                replication_config=replication_config,
                vector_index_config=vector_index_config,
                vectorizer_config=vectorizer_config,
                object_ttl_config=object_ttl_config,
                multi_tenancy_config=multi_tenancy_config,
                generative_config=generative_config,
                reranker_config=reranker_config,
                vector_config=vector_config,
            )
        except ValidationError as e:
            raise WeaviateInvalidInputError("Invalid collection config update parameters.") from e

        def resp(schema: Dict[str, Any]) -> executor.Result[None]:
            schema = config.merge_with_existing(schema)

            def inner_resp(res: Response) -> None:
                return None

            return executor.execute(
                response_callback=inner_resp,
                method=self._connection.put,
                path=f"/schema/{self._name}",
                weaviate_object=schema,
                error_msg="Collection configuration may not have been updated.",
                status_codes=_ExpectedStatusCodes(
                    ok_in=200, error="Update collection configuration"
                ),
            )

        if isinstance(self._connection, ConnectionAsync):

            async def _execute() -> None:
                schema = await executor.aresult(self.__get())
                return await executor.aresult(resp(schema))

            return _execute()
        schema = executor.result(self.__get())
        return executor.result(resp(schema))

    def __add_property(self, additional_property: PropertyType) -> executor.Result[None]:
        if isinstance(additional_property, Property) and _property_has_text_analyzer(
            additional_property
        ):
            if not self._connection._weaviate_version.is_at_least(1, 37, 0):
                raise WeaviateUnsupportedFeatureError(
                    "Property text_analyzer (asciiFold)",
                    str(self._connection._weaviate_version),
                    "1.37.0",
                )
        path = f"/schema/{self._name}/properties"
        obj = additional_property._to_dict()

        def resp(schema: Dict[str, Any]) -> executor.Result[None]:
            modconf = {}
            if "skip_vectorization" in obj:
                modconf["skip"] = obj["skip_vectorization"]
                del obj["skip_vectorization"]

            if "vectorize_property_name" in obj:
                modconf["vectorizePropertyName"] = obj["vectorize_property_name"]
                del obj["vectorize_property_name"]

            module_config: Dict[str, Any] = schema.get("moduleConfig", {})
            legacy_vectorizer = [
                str(k) for k in module_config if "generative" not in k and "reranker" not in k
            ]
            if len(legacy_vectorizer) > 0 and len(modconf) > 0:
                obj["moduleConfig"] = {legacy_vectorizer[0]: modconf}

            vector_config: Dict[str, Any] = schema.get("vectorConfig", {})
            if len(vector_config) > 0:
                obj["moduleConfig"] = {
                    list(conf["vectorizer"].keys()).pop(): modconf
                    for conf in vector_config.values()
                }

            def inner_resp(res: Response) -> None:
                return None

            return executor.execute(
                response_callback=inner_resp,
                method=self._connection.post,
                path=path,
                weaviate_object=obj,
                error_msg="Property may not have been added properly.",
                status_codes=_ExpectedStatusCodes(ok_in=200, error="Add property to collection"),
            )

        if isinstance(self._connection, ConnectionAsync):

            async def _execute() -> None:
                schema = await executor.aresult(self.__get())
                return await executor.aresult(resp(schema))

            return _execute()
        schema = executor.result(self.__get())
        return executor.result(resp(schema))

    def __property_exists(self, property_name: str) -> executor.Result[bool]:
        def resp(schema: Dict[str, Any]) -> bool:
            conf = _collection_config_simple_from_json(schema)
            if len(conf.properties) == 0:
                return False
            for prop in conf.properties:
                if prop.name == property_name:
                    return True
            return False

        return executor.execute(
            response_callback=resp,
            method=self.__get,
        )

    def __reference_exists(self, reference_name: str) -> executor.Result[bool]:
        def resp(schema: Dict[str, Any]) -> bool:
            conf = _collection_config_simple_from_json(schema)
            if len(conf.references) == 0:
                return False
            for ref in conf.references:
                if ref.name == reference_name:
                    return True
            return False

        return executor.execute(
            response_callback=resp,
            method=self.__get,
        )

    def __get_shards(self) -> executor.Result[List[ShardStatus]]:
        def resp(res: Response) -> List[ShardStatus]:
            shards = _decode_json_response_list(res, "get shards")
            assert shards is not None
            return [
                _ShardStatus(
                    name=shard["name"],
                    status=shard.get("status", ""),
                    vector_queue_size=shard["vectorQueueSize"],
                    per_node_status=shard.get("per_node_status"),
                )
                for shard in shards
            ]

        return executor.execute(
            response_callback=resp,
            method=self._connection.get,
            path=f"/schema/{self._name}/shards{f'?tenant={self._tenant}' if self._tenant else ''}",
            error_msg="Shard statuses could not be retrieved.",
        )

    def get_shards(self) -> executor.Result[List[ShardStatus]]:
        """Get the statuses of the shards of this collection.

        If the collection is multi-tenancy and you did not call `.with_tenant` then you
        will receive the statuses of all the tenants within the collection. Otherwise, call
        `.with_tenant` on the collection first and you will receive only that single shard.

        Returns:
            A list of objects containing the statuses of the shards.

        Raises:
            weaviate.exceptions.WeaviateConnectionError: If the network connection to Weaviate fails.
            weaviate.exceptions.UnexpectedStatusCodeError: If Weaviate reports a non-OK status.
        """
        return self.__get_shards()

    def __update_shard(
        self, shard_name: str, status: str
    ) -> executor.Result[Tuple[str, ShardTypes]]:
        path = f"/schema/{self._name}/shards/{shard_name}"
        data = {"status": status}

        def resp(res: Response) -> Tuple[str, ShardTypes]:
            shard = _decode_json_response_dict(res, f"Update shard '{shard_name}' status")
            assert shard is not None
            return shard_name, shard["status"]

        return executor.execute(
            response_callback=resp,
            method=self._connection.put,
            path=path,
            weaviate_object=data,
            error_msg=f"shard '{shard_name}' may not have been updated.",
        )

    def update_shards(
        self,
        status: Literal["READY", "READONLY"],
        shard_names: Optional[Union[str, List[str]]] = None,
    ) -> executor.Result[Dict[str, ShardTypes]]:
        """Update the status of one or all shards of this collection.

        Args:
            status: The new status of the shard. The available options are: 'READY' and 'READONLY'.
            shard_name: The shard name for which to update the status of the class of the shard. If None all shards are going to be updated.

        Returns:
            All updated shards indexed by their name.

        Raises:
            weaviate.exceptions.WeaviateConnectionError: If the network connection to Weaviate fails.
            weaviate.exceptions.UnexpectedStatusCodeError: If Weaviate reports a non-OK status.
        """
        if isinstance(self._connection, ConnectionAsync):

            async def _execute(
                shard_names: Optional[Union[str, List[str]]],
            ) -> Dict[str, ShardTypes]:
                if shard_names is None:
                    shards_config = await executor.aresult(self.__get_shards())
                    shard_names = [shard_config.name for shard_config in shards_config]
                elif isinstance(shard_names, str):
                    shard_names = [shard_names]

                results = await asyncio.gather(
                    *[
                        executor.aresult(self.__update_shard(shard_name=shard_name, status=status))
                        for shard_name in shard_names
                    ]
                )

                return {result[0]: result[1] for result in results}

            return _execute(shard_names)

        if shard_names is None:
            shards_config = executor.result(self.__get_shards())
            shard_names = [shard_config.name for shard_config in shards_config]
        elif isinstance(shard_names, str):
            shard_names = [shard_names]

        return {
            result[0]: result[1]
            for result in [
                executor.result(self.__update_shard(shard_name=shard_name, status=status))
                for shard_name in shard_names
            ]
        }

    def add_property(self, prop: Property) -> executor.Result[None]:
        """Add a property to the collection in Weaviate.

        Args:
            prop: The property to add to the collection.

        Raises:
            weaviate.exceptions.WeaviateConnectionError: If the network connection to Weaviate fails.
            weaviate.exceptions.UnexpectedStatusCodeError: If Weaviate reports a non-OK status.
            weaviate.exceptions.WeaviateInvalidInputError: If the property already exists in the collection.
        """
        _validate_input([_ValidateArgument(expected=[Property], name="prop", value=prop)])

        def resp(exists: bool) -> executor.Result[None]:
            if exists:
                raise WeaviateInvalidInputError(
                    f"Property with name '{prop.name}' already exists in collection '{self._name}'."
                )
            return self.__add_property(additional_property=prop)

        if isinstance(self._connection, ConnectionAsync):

            async def _execute() -> None:
                exists = await executor.aresult(self.__property_exists(property_name=prop.name))
                return await executor.aresult(resp(exists))

            return _execute()
        exists = executor.result(self.__property_exists(property_name=prop.name))
        return executor.result(resp(exists))

    def add_reference(
        self,
        ref: Union[ReferenceProperty, ReferencePropertyMultiTarget],
    ) -> executor.Result[None]:
        """Add a reference to the collection in Weaviate.

        Args:
            ref: The reference to add to the collection.

        Raises:
            weaviate.exceptions.WeaviateConnectionError: If the network connection to Weaviate fails.
            weaviate.exceptions.UnexpectedStatusCodeError: If Weaviate reports a non-OK status.
            weaviate.exceptions.WeaviateInvalidInputError: If the reference already exists in the collection.
        """
        _validate_input(
            [
                _ValidateArgument(
                    expected=[ReferenceProperty, ReferencePropertyMultiTarget],
                    name="ref",
                    value=ref,
                )
            ]
        )

        def resp(exists: bool) -> executor.Result[None]:
            if exists:
                raise WeaviateInvalidInputError(
                    f"Reference with name '{ref.name}' already exists in collection '{self._name}'."
                )
            return self.__add_property(additional_property=ref)

        if isinstance(self._connection, ConnectionAsync):

            async def _execute() -> None:
                exists = await executor.aresult(self.__reference_exists(reference_name=ref.name))
                return await executor.aresult(resp(exists))

            return _execute()
        exists = executor.result(self.__reference_exists(reference_name=ref.name))
        return executor.result(resp(exists))

    @overload
    @deprecated(
        "Using `Configure.NamedVectors` in `vector_config` is deprecated. Instead, use `Configure.Vectors` or `Configure.MultiVectors`."
    )
    def add_vector(
        self, *, vector_config: Union[_NamedVectorConfigCreate, List[_NamedVectorConfigCreate]]
    ) -> executor.Result[None]: ...

    @overload
    def add_vector(
        self, *, vector_config: Union[VectorConfigCreate, List[VectorConfigCreate]]
    ) -> executor.Result[None]: ...

    def add_vector(
        self,
        *,
        vector_config: Union[
            _NamedVectorConfigCreate,
            VectorConfigCreate,
            List[_NamedVectorConfigCreate],
            List[VectorConfigCreate],
        ],
    ) -> executor.Result[None]:
        """Add a vector to the collection in Weaviate.

        Args:
            vector_config: The vector configuration to add to the collection.

        Raises:
            weaviate.exceptions.WeaviateConnectionError: If the network connection to Weaviate fails.
            weaviate.exceptions.UnexpectedStatusCodeError: If Weaviate reports a non-OK status.
            weaviate.exceptions.WeaviateInvalidInputError: If the vector already exists in the collection.
        """
        _validate_input(
            [
                _ValidateArgument(
                    expected=[
                        _NamedVectorConfigCreate,
                        VectorConfigCreate,
                        List[_NamedVectorConfigCreate],
                        List[VectorConfigCreate],
                    ],
                    name="vector_config",
                    value=vector_config,
                )
            ]
        )
        if isinstance(vector_config, list):
            for c in vector_config:
                if isinstance(c, _NamedVectorConfigCreate):
                    _Warnings.named_vector_syntax_in_config_add_vector(c.name)
                if c.name is None:
                    raise WeaviateInvalidInputError(
                        "The configured vector must have a name when adding it to a collection."
                    )
        if isinstance(vector_config, _NamedVectorConfigCreate):
            _Warnings.named_vector_syntax_in_config_add_vector(vector_config.name)
            vector_config = [vector_config]
        if isinstance(vector_config, VectorConfigCreate):
            vector_config = [vector_config]

        def resp(schema: Dict[str, Any]) -> executor.Result[None]:
            if "vectorConfig" not in schema:
                schema["vectorConfig"] = {}
            for vector in vector_config:
                schema["vectorConfig"][vector.name] = vector._to_dict()

            return executor.execute(
                response_callback=lambda _: None,
                method=self._connection.put,
                path=f"/schema/{self._name}",
                weaviate_object=schema,
                error_msg="Collection configuration may not have been updated.",
                status_codes=_ExpectedStatusCodes(
                    ok_in=200, error="Update collection configuration"
                ),
            )

        if isinstance(self._connection, ConnectionAsync):

            async def _execute() -> None:
                schema = await executor.aresult(self.__get())
                return await executor.aresult(resp(schema))

            return _execute()
        schema = executor.result(self.__get())
        return executor.result(resp(schema))

    def delete_property_index(
        self,
        property_name: str,
        index_name: IndexName,
    ) -> executor.Result[bool]:
        """Delete a property index from the collection in Weaviate.

            This is a destructive operation. The index will
            need to be regenerated if you wish to use it again.

        Args:
            property_name: The property name from which to delete the index.
            index_name: The type of the index to delete.

        Raises:
            weaviate.exceptions.WeaviateConnectionError: If the network connection to Weaviate fails.
            weaviate.exceptions.UnexpectedStatusCodeError: If Weaviate reports a non-OK status.
            weaviate.exceptions.WeaviateInvalidInputError: If the property or index does not exist.
        """
        _validate_input(
            [_ValidateArgument(expected=[str], name="property_name", value=property_name)]
        )
        _validate_input([_ValidateArgument(expected=[str], name="index_name", value=index_name)])

        path = (
            f"/schema/{_capitalize_first_letter(self._name)}"
            + f"/properties/{property_name}"
            + f"/index/{index_name}"
        )

        def resp(res: Response) -> bool:
            return res.status_code == 200

        return executor.execute(
            response_callback=resp,
            method=self._connection.delete,
            path=path,
            error_msg="Property may not exist",
            status_codes=_ExpectedStatusCodes(ok_in=[200], error="property exists"),
        )

    def delete_vector_index(
        self,
        vector_name: str,
    ) -> executor.Result[None]:
        """Delete the index of a named vector of the collection in Weaviate.

            This is a destructive and irreversible operation. Once the drop completes, the index is
            deleted from disk and the vector's data is removed from every object in the collection.
            Neither can be restored. A new, empty vector with the same name can be added again with
            `collection.config.add_vector()` after the drop has completed, but not before. Searches
            and writes targeting the vector are rejected once the index is gone.

            The drop is applied asynchronously. A successful call means that Weaviate accepted the
            request, not that the index is already gone. `collection.config.get()` first reports the
            vector with a `vector_index_config` of `VectorIndexConfigNone` and drops it from
            `vector_config` altogether once the drop has completed. Repeating the call while the
            drop is still in progress succeeds and re-triggers the cleanup; once the vector is gone
            from the schema, the same call is rejected with a 422 because the vector no longer
            exists.

            Only named vectors can be dropped. The endpoint is experimental and may be disabled
            server-side, in which case Weaviate rejects the request.

        Args:
            vector_name: The name of the named vector whose index to delete.

        Raises:
            weaviate.exceptions.WeaviateConnectionError: If the network connection to Weaviate fails.
            weaviate.exceptions.UnexpectedStatusCodeError: If Weaviate reports a non-OK status, e.g.
                if the vector does not exist (including repeating the call after the drop completed)
                or if the endpoint is disabled on the server.
            weaviate.exceptions.WeaviateInvalidInputError: If `vector_name` is not a string.
        """
        _validate_input([_ValidateArgument(expected=[str], name="vector_name", value=vector_name)])

        path = f"/schema/{_capitalize_first_letter(self._name)}/vectors/{vector_name}/index"

        def resp(res: Response) -> None:
            return None

        return executor.execute(
            response_callback=resp,
            method=self._connection.delete,
            path=path,
            error_msg="Vector index may not have been deleted",
            status_codes=_ExpectedStatusCodes(ok_in=[200], error="delete vector index"),
        )
