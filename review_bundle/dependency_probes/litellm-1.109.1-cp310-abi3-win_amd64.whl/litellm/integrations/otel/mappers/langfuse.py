"""Langfuse OTLP attribute mapper.

Langfuse ingests OTLP spans and reads from its own vendor namespace
(``langfuse.observation.*``, ``langfuse.trace.*``). Compose this mapper after
``GenAIMapper`` to send canonical + Langfuse-flavored spans simultaneously.

Every attribute is declared as a ``key -> extractor`` table entry (one callable
per mapping operation): ``_LLM_CALL_ATTRS`` for scalars and ``_BLOB_ATTRS`` for
the JSON-serialized payloads. ``trace_attributes`` maps the caller's trace controls
(shared with the root observation); ``_llm_call`` applies both tables plus it.
"""

import json
from collections.abc import Callable
from datetime import datetime, timezone
from types import MappingProxyType
from typing import Final

from litellm.integrations.langfuse.langfuse_otel_attributes import serialize_langfuse_datetime
from litellm.integrations.otel.mappers.base import AttributeMap, AttrValue, SpanData
from litellm.integrations.otel.mappers.utils import (
    collect,
    drop_none_pairs,
    json_if,
    output_messages,
    serialize_messages,
)
from litellm.integrations.otel.model.metadata import IDENTITY_METADATA_FIELDS
from litellm.integrations.otel.model.payloads import (
    LLMCallSpanData,
    LLMRequestParams,
    LLMUsage,
)
from litellm.integrations.otel.model.trace_controls import TraceControls

LANGFUSE_OBSERVATION_INPUT: Final = "langfuse.observation.input"
LANGFUSE_OBSERVATION_OUTPUT: Final = "langfuse.observation.output"
LANGFUSE_TRACE_NAME: Final = "langfuse.trace.name"
LANGFUSE_TRACE_USER_ID: Final = "user.id"
LANGFUSE_TRACE_SESSION_ID: Final = "session.id"
LANGFUSE_TRACE_TAGS: Final = "langfuse.trace.tags"
LANGFUSE_OBSERVATION_METADATA: Final = "langfuse.observation.metadata"
LANGFUSE_TRACE_METADATA_PREFIX: Final = "langfuse.trace.metadata."
LANGFUSE_REQUEST_METADATA_ATTRIBUTES: Final[frozenset[str]] = frozenset(
    {LANGFUSE_OBSERVATION_METADATA, *(f"{LANGFUSE_TRACE_METADATA_PREFIX}{name}" for name in IDENTITY_METADATA_FIELDS)}
)


def _identity_field(name: str) -> Callable[[LLMCallSpanData], AttrValue | None]:
    return lambda d: d.request_metadata.get(name)


class LangfuseMapper:
    _LLM_CALL_ATTRS: dict[str, Callable[[LLMCallSpanData], AttrValue | None]] = {
        "langfuse.observation.type": lambda _: "generation",
        "langfuse.observation.model.name": lambda d: d.request_model or None,
        "langfuse.observation.metadata.provider": lambda d: d.provider or None,
        "langfuse.observation.id": lambda d: d.identity.call_id or None,
        "langfuse.trace.metadata.team_id": lambda d: d.identity.team_id or None,
        "langfuse.trace.metadata.team_alias": lambda d: d.identity.team_alias or None,
        "langfuse.observation.completion_start_time": lambda d: (
            serialize_langfuse_datetime(datetime.fromtimestamp(d.completion_start_seconds, tz=timezone.utc))
            if d.completion_start_seconds is not None
            else None
        ),
        **MappingProxyType(
            {f"{LANGFUSE_TRACE_METADATA_PREFIX}{name}": _identity_field(name) for name in IDENTITY_METADATA_FIELDS}
        ),
    }

    # Sub-tables folded into their respective JSON blobs.
    _MODEL_PARAMS: dict[str, Callable[[LLMRequestParams], AttrValue | None]] = {
        "temperature": lambda rp: rp.temperature,
        "top_p": lambda rp: rp.top_p,
        "max_tokens": lambda rp: rp.max_tokens,
        "frequency_penalty": lambda rp: rp.frequency_penalty,
        "presence_penalty": lambda rp: rp.presence_penalty,
        "seed": lambda rp: rp.seed,
    }
    # Langfuse prices every key, and litellm's prompt/completion counts include cache and reasoning tokens
    _USAGE_FIELDS: dict[str, Callable[[LLMUsage], AttrValue | None]] = {
        "input": lambda u: u.uncached_input_tokens,
        "input_cached_tokens": lambda u: u.cache_read_input_tokens or None,
        "input_cache_creation": lambda u: u.cache_creation_input_tokens or None,
        "output": lambda u: u.non_reasoning_output_tokens,
        "output_reasoning_tokens": lambda u: u.reasoning_tokens or None,
        "total": lambda u: u.total_tokens,
    }

    # JSON-payload attributes: each builder returns the serialized blob or None.
    _BLOB_ATTRS: dict[str, Callable[[LLMCallSpanData], AttrValue | None]] = {
        LANGFUSE_OBSERVATION_METADATA: lambda d: json_if(dict(d.request_metadata)),
        "langfuse.observation.model.parameters": lambda d: json_if(
            collect(LangfuseMapper._MODEL_PARAMS, d.request_params)
        ),
        LANGFUSE_OBSERVATION_INPUT: lambda d: serialize_messages(d.messages_in),
        LANGFUSE_OBSERVATION_OUTPUT: lambda d: (
            d.embedding_output.as_json() if d.embedding_output is not None else serialize_messages(output_messages(d))
        ),
        "langfuse.observation.usage_details": lambda d: json_if(collect(LangfuseMapper._USAGE_FIELDS, d.usage)),
        "langfuse.observation.cost_details": lambda d: (
            json.dumps({"total": d.response_cost}) if d.response_cost is not None else None
        ),
    }

    #: Every attribute this mapper can write on a model call.
    LLM_CALL_ATTRIBUTES: Final[frozenset[str]] = frozenset(
        {
            *_LLM_CALL_ATTRS,
            *_BLOB_ATTRS,
            LANGFUSE_TRACE_NAME,
            LANGFUSE_TRACE_USER_ID,
            LANGFUSE_TRACE_SESSION_ID,
            LANGFUSE_TRACE_TAGS,
        }
    )

    def map(self, data: SpanData) -> AttributeMap:
        match data:
            case LLMCallSpanData():
                return self._llm_call(data)
            case _:
                return {}

    @staticmethod
    def trace_attributes(trace: TraceControls, call_type: str | None = None) -> AttributeMap:
        return drop_none_pairs(
            (
                (LANGFUSE_TRACE_NAME, trace.name or (f"litellm-{call_type}" if call_type else None)),
                (LANGFUSE_TRACE_USER_ID, trace.user_id or None),
                (LANGFUSE_TRACE_SESSION_ID, trace.session_id or None),
                (LANGFUSE_TRACE_TAGS, trace.tags or None),
            )
        )

    @classmethod
    def _llm_call(cls, data: LLMCallSpanData) -> AttributeMap:
        return {
            **collect(cls._LLM_CALL_ATTRS, data),
            **cls.trace_attributes(data.trace),
            **collect(cls._BLOB_ATTRS, data),
        }
